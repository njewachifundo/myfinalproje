
// Mock user data for the application

export type UserRole = 'customer' | 'staff' | 'admin' | 'management';

export interface User {
  id: string;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  avatar?: string;
}

// Mock users for different roles
export const mockUsers: Record<string, { password: string; user: User }> = {
  'customer1': {
    password: 'password1',
    user: {
      id: '1',
      username: 'customer1',
      email: 'customer@example.com',
      firstName: 'John',
      lastName: 'Mbvundula',
      role: 'customer',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
    }
  },
  'staff1': {
    password: 'password1',
    user: {
      id: '2',
      username: 'staff1',
      email: 'staff@nrwb.mw',
      firstName: 'Sarah',
      lastName: 'Chirwa',
      role: 'staff',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
    }
  },
  'admin1': {
    password: 'password1',
    user: {
      id: '3',
      username: 'admin1',
      email: 'admin@nrwb.mw',
      firstName: 'Chikondi',
      lastName: 'Gama',
      role: 'admin',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Michael',
    }
  },
  'manager1': {
    password: 'password1',
    user: {
      id: '4',
      username: 'manager1',
      email: 'manager@nrwb.mw',
      firstName: 'Elizabeth',
      lastName: 'Banda',
      role: 'management',
      avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Elizabeth',
    }
  },
};

// Function to authenticate a user
export const authenticateUser = (username: string, password: string): User | null => {
  const userRecord = mockUsers[username];
  
  if (userRecord && userRecord.password === password) {
    return userRecord.user;
  }
  
  return null;
};
