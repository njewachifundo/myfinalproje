
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

// Auth Provider
import { AuthProvider } from "./contexts/AuthContext";

// Layout
import AppLayout from "./components/layout/AppLayout";

// Pages
import LandingPage from "./pages/LandingPage";
import LoginPage from "./pages/auth/LoginPage";
import RegisterPage from "./pages/auth/RegisterPage";
import NotFound from "./pages/NotFound";

// Role-specific dashboards
import CustomerDashboard from "./pages/dashboard/CustomerDashboard";
import StaffDashboard from "./pages/dashboard/StaffDashboard";
import AdminDashboard from "./pages/dashboard/AdminDashboard";
import ManagementDashboard from "./pages/dashboard/ManagementDashboard";

// Customer Pages
import NewApplicationPage from "./pages/application/NewApplicationPage";
import StatusPage from "./pages/application/StatusPage";
import PaymentsPage from "./pages/customers/PaymentsPage";
import SupportPage from "./pages/customers/SupportPage";
import ProfilePage from "./pages/customers/ProfilePage";
import FaqsPage from "./pages/customers/FaqsPage";
import ContactPage from "./pages/customers/ContactPage";

// Staff Pages
import ApplicationManagementPage from "./pages/staff/ApplicationManagementPage";
import CustomerManagementPage from "./pages/staff/CustomerManagementPage";
import PaymentProcessingPage from "./pages/staff/PaymentProcessingPage";
import GisMonitoringPage from "./pages/staff/GisMonitoringPage";
import ReportsPage from "./pages/staff/ReportsPage";
import SupportTicketsPage from "./pages/staff/SupportTicketsPage";
import SettingsPage from "./pages/staff/SettingsPage";

// Admin Pages
import UserManagementPage from "./pages/admin/UserManagementPage";
import SystemConfigPage from "./pages/admin/SystemConfigPage";
import SecurityPage from "./pages/admin/SecurityPage";
import AuditLogsPage from "./pages/admin/AuditLogsPage";
import BackupPage from "./pages/admin/BackupPage";
import ApiIntegrationPage from "./pages/admin/ApiIntegrationPage";
import SystemReportsPage from "./pages/admin/SystemReportsPage";

// Management Pages
import StrategicReportsPage from "./pages/management/StrategicReportsPage";
import PerformanceAnalyticsPage from "./pages/management/PerformanceAnalyticsPage";
import ResourceAllocationPage from "./pages/management/ResourceAllocationPage";
import SystemAuditPage from "./pages/management/SystemAuditPage";
import FinancialPage from "./pages/management/FinancialPage";

// DashboardPage component that renders the appropriate dashboard based on user role
import DashboardPage from "./pages/dashboard/DashboardPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            
            {/* Protected Routes (all inside AppLayout) */}
            <Route element={<AppLayout />}>
              {/* Dashboard - Available for all roles, but will show different content */}
              <Route path="/dashboard" element={<DashboardPage />} />
              
              {/* Customer Routes */}
              <Route path="/application/new" element={<NewApplicationPage />} />
              <Route path="/application/status" element={<StatusPage />} />
              <Route path="/payments" element={<PaymentsPage />} />
              <Route path="/support" element={<SupportPage />} />
              <Route path="/profile" element={<ProfilePage />} />
              <Route path="/faqs" element={<FaqsPage />} />
              <Route path="/contact" element={<ContactPage />} />
              
              {/* Staff Routes */}
              <Route path="/application-management" element={<ApplicationManagementPage />} />
              <Route path="/customer-management" element={<CustomerManagementPage />} />
              <Route path="/payment-processing" element={<PaymentProcessingPage />} />
              <Route path="/gis-monitoring" element={<GisMonitoringPage />} />
              <Route path="/reports" element={<ReportsPage />} />
              <Route path="/support-tickets" element={<SupportTicketsPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              
              {/* Admin Routes */}
              <Route path="/user-management" element={<UserManagementPage />} />
              <Route path="/system-config" element={<SystemConfigPage />} />
              <Route path="/security" element={<SecurityPage />} />
              <Route path="/audit-logs" element={<AuditLogsPage />} />
              <Route path="/backup" element={<BackupPage />} />
              <Route path="/api-integration" element={<ApiIntegrationPage />} />
              <Route path="/system-reports" element={<SystemReportsPage />} />
              
              {/* Management Routes */}
              <Route path="/strategic-reports" element={<StrategicReportsPage />} />
              <Route path="/performance-analytics" element={<PerformanceAnalyticsPage />} />
              <Route path="/resource-allocation" element={<ResourceAllocationPage />} />
              <Route path="/system-audit" element={<SystemAuditPage />} />
              <Route path="/financial" element={<FinancialPage />} />
            </Route>
            
            {/* Catch-all for 404 */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
