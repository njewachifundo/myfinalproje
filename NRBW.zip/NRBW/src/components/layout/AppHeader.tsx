
import React from 'react';
import { SidebarTrigger, useSidebar } from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Bell, UserCircle, LogOut } from 'lucide-react';
import { 
  DropdownMenu, 
  DropdownMenuTrigger, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator 
} from '@/components/ui/dropdown-menu';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const AppHeader: React.FC = () => {
  const sidebar = useSidebar();
  const { user, logout } = useAuth();
  
  return (
    <header className="h-16 border-b border-border/40 px-4 flex items-center justify-between glass-dark">
      <div className="flex items-center">
        <SidebarTrigger className="mr-4" />
        <h1 className="text-xl font-semibold text-nrwb-light hidden md:block">NRWB Portal</h1>
      </div>
      
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon">
          <Bell size={20} className="text-nrwb-muted hover:text-nrwb-accent transition-colors" />
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <UserCircle size={28} className="text-nrwb-accent" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 glass-dark border-nrwb-accent/20">
            {user && (
              <div className="flex items-center justify-start gap-2 p-2">
                <div className="rounded-full bg-nrwb-accent w-10 h-10 flex items-center justify-center">
                  <UserCircle className="h-8 w-8 text-nrwb-dark" />
                </div>
                <div className="flex flex-col space-y-0.5">
                  <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                  <p className="text-xs text-nrwb-muted">{user.email}</p>
                  <p className="text-xs bg-nrwb-accent/20 text-nrwb-accent px-2 py-0.5 rounded-full w-fit capitalize">
                    {user.role}
                  </p>
                </div>
              </div>
            )}
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link to="/profile" className="cursor-pointer">Profile Settings</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to="/support" className="cursor-pointer">Support Center</Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout} className="cursor-pointer text-red-400 flex items-center gap-2">
              <LogOut size={16} /> Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default AppHeader;
