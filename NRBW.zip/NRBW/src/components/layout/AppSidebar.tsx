
import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from '@/components/ui/sidebar';
import {
  LayoutDashboard,
  FileText,
  FileSearch,
  CreditCard,
  HelpCircle,
  User,
  PhoneCall,
  Users,
  DollarSign,
  Map,
  BarChart2,
  Settings,
  Shield,
  FileDigit,
  Database,
  Webhook,
  TrendingUp,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';

const AppSidebar: React.FC = () => {
  const sidebar = useSidebar();
  const location = useLocation();
  const { user } = useAuth();
  const currentPath = location.pathname;

  // Define navigation items for each role
  const customerNavItems = [
    { 
      title: 'Dashboard', 
      url: '/dashboard', 
      icon: LayoutDashboard 
    },
    { 
      title: 'New Connection', 
      url: '/application/new', 
      icon: FileText 
    },
    { 
      title: 'Application Status', 
      url: '/application/status', 
      icon: FileSearch 
    },
    { 
      title: 'Payment History', 
      url: '/payments', 
      icon: CreditCard 
    },
    { 
      title: 'Support Center', 
      url: '/support', 
      icon: HelpCircle 
    },
    { 
      title: 'Profile Settings', 
      url: '/profile', 
      icon: User 
    },
    { 
      title: 'FAQs', 
      url: '/faqs', 
      icon: HelpCircle 
    },
    { 
      title: 'Contact NRWB', 
      url: '/contact', 
      icon: PhoneCall 
    },
  ];

  const staffNavItems = [
    { 
      title: 'Dashboard', 
      url: '/dashboard', 
      icon: LayoutDashboard 
    },
    { 
      title: 'Application Management', 
      url: '/application-management', 
      icon: FileText 
    },
    { 
      title: 'Customer Management', 
      url: '/customer-management', 
      icon: Users 
    },
    { 
      title: 'Payment Processing', 
      url: '/payment-processing', 
      icon: DollarSign 
    },
    { 
      title: 'GIS Monitoring', 
      url: '/gis-monitoring', 
      icon: Map 
    },
    { 
      title: 'Reports & Analytics', 
      url: '/reports', 
      icon: BarChart2 
    },
    { 
      title: 'Support Tickets', 
      url: '/support-tickets', 
      icon: HelpCircle 
    },
    { 
      title: 'System Settings', 
      url: '/settings', 
      icon: Settings 
    },
  ];

  const adminNavItems = [
    { 
      title: 'System Dashboard', 
      url: '/dashboard', 
      icon: LayoutDashboard 
    },
    { 
      title: 'User Management', 
      url: '/user-management', 
      icon: Users 
    },
    { 
      title: 'System Configuration', 
      url: '/system-config', 
      icon: Settings 
    },
    { 
      title: 'Security Settings', 
      url: '/security', 
      icon: Shield 
    },
    { 
      title: 'Audit Logs', 
      url: '/audit-logs', 
      icon: FileDigit 
    },
    { 
      title: 'Backup & Restore', 
      url: '/backup', 
      icon: Database 
    },
    { 
      title: 'API Integration', 
      url: '/api-integration', 
      icon: Webhook 
    },
    { 
      title: 'System Reports', 
      url: '/system-reports', 
      icon: BarChart2 
    },
  ];

  const managementNavItems = [
    { 
      title: 'Executive Dashboard', 
      url: '/dashboard', 
      icon: LayoutDashboard 
    },
    { 
      title: 'Strategic Reports', 
      url: '/strategic-reports', 
      icon: BarChart2 
    },
    { 
      title: 'Performance Analytics', 
      url: '/performance-analytics', 
      icon: TrendingUp 
    },
    { 
      title: 'Resource Allocation', 
      url: '/resource-allocation', 
      icon: Database 
    },
    { 
      title: 'System Audit', 
      url: '/system-audit', 
      icon: Shield 
    },
    { 
      title: 'Financial Overview', 
      url: '/financial', 
      icon: DollarSign 
    },
  ];

  // Select the appropriate nav items based on user role
  let navItems = customerNavItems; // default
  if (user) {
    switch (user.role) {
      case 'staff':
        navItems = staffNavItems;
        break;
      case 'admin':
        navItems = adminNavItems;
        break;
      case 'management':
        navItems = managementNavItems;
        break;
      default:
        navItems = customerNavItems;
    }
  }
  
  // Helper to determine if route is active
  const isActive = (path: string) => currentPath === path || currentPath.startsWith(path);
  
  return (
    <Sidebar
      className={cn(
        "transition-all duration-300 border-r border-border/40",
        sidebar.state === "collapsed" ? "w-16" : "w-64"
      )}
    >
      {sidebar.state === "collapsed" ? null : (
        <div className="p-4 flex items-center justify-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-nrwb-accent to-nrwb-light bg-clip-text text-transparent">
            NRWB
          </h1>
        </div>
      )}
      
      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupLabel className={cn(sidebar.state !== "collapsed" && "text-nrwb-accent text-xs")}>
            {sidebar.state !== "collapsed" && "MAIN MENU"}
          </SidebarGroupLabel>
          
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild>
                    <NavLink 
                      to={item.url} 
                      className={({ isActive }) => cn(
                        "flex items-center gap-2 px-3 py-2 rounded-md transition-colors",
                        isActive 
                          ? "bg-nrwb-accent/20 text-nrwb-accent" 
                          : "hover:bg-nrwb-dark/60 text-nrwb-muted hover:text-nrwb-light"
                      )}
                    >
                      <item.icon size={sidebar.state === "collapsed" ? 20 : 18} />
                      {sidebar.state !== "collapsed" && <span className="text-sm">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
};

export default AppSidebar;
