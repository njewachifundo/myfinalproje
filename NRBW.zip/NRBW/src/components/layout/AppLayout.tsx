
import React, { useEffect } from 'react';
import { SidebarProvider } from '@/components/ui/sidebar';
import AppSidebar from './AppSidebar';
import AppHeader from './AppHeader';
import { Toaster } from '@/components/ui/sonner';
import { Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react';

const AppLayout: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  
  // Redirect unauthenticated users to login
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, isLoading, navigate]);
  
  // Show loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-nrwb-darkest">
        <div className="flex flex-col items-center">
          <Loader2 className="h-12 w-12 text-nrwb-accent animate-spin" />
          <p className="mt-4 text-nrwb-muted">Loading...</p>
        </div>
      </div>
    );
  }
  
  // Only render the layout if authenticated
  if (!isAuthenticated) return null;
  
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1">
          <AppHeader />
          <main className="flex-1 p-4 md:p-6 overflow-y-auto">
            <div className="container mx-auto">
              <Outlet />
            </div>
          </main>
          <footer className="py-4 px-6 text-center text-nrwb-muted text-sm">
            <p>© {new Date().getFullYear()} Northern Region Water Board. All rights reserved.</p>
          </footer>
        </div>
        <Toaster />
      </div>
    </SidebarProvider>
  );
};

export default AppLayout;
