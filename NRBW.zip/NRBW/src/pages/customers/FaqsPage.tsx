
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';

const FaqsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const faqItems = [
    {
      question: "How do I apply for a new water connection?",
      answer: "To apply for a new water connection, you can use our online application portal by logging into your account and clicking on 'New Connection' in the sidebar. Follow the step-by-step process to submit your application, upload required documents, and pay the application fee."
    },
    {
      question: "What documents do I need for a new connection application?",
      answer: "For a new connection application, you typically need: 1) Proof of property ownership or tenancy agreement, 2) Property location map or sketch, 3) National ID or passport, 4) Recent passport-sized photograph, and 5) Land title deed or certificate of occupancy where applicable."
    },
    {
      question: "How long does it take to process a new connection?",
      answer: "The standard processing time for new connections is 7-14 working days from the submission of a complete application with all required documents. Complex connections or those in remote areas may take slightly longer."
    },
    {
      question: "What are the fees involved in getting a new connection?",
      answer: "The fees for a new connection include: 1) Application fee (non-refundable), 2) Connection fee (varies based on distance and complexity), 3) Security deposit, and 4) Meter installation fee. A detailed quote will be provided after your site has been assessed."
    },
    {
      question: "How do I pay my water bill?",
      answer: "You can pay your water bill through multiple channels: 1) Online through our customer portal, 2) Mobile money (TNM Mpamba or Airtel Money), 3) Bank transfer to our account, 4) At any NRWB office, or 5) Through authorized payment agents across the Northern Region."
    },
    {
      question: "How often will I receive my water bill?",
      answer: "Water bills are generated monthly based on your meter readings. You can access your bill through your online account, or receive it via email or SMS if you've registered for our notification service."
    },
    {
      question: "What should I do if I notice a water leak?",
      answer: "If you notice a water leak, please report it immediately through our emergency reporting system in the Support Center, or call our emergency hotline at +265 888 123 456. For leaks within your property, you may need to contact a licensed plumber."
    },
    {
      question: "How can I check the status of my application?",
      answer: "You can check the status of your application by logging into your account and navigating to 'Application Status' in the sidebar. There you can see the current stage of your application, any pending requirements, and estimated completion timelines."
    },
    {
      question: "What happens after my application is approved?",
      answer: "After your application is approved, you will receive a notification to pay the connection fees. Once payment is confirmed, our technical team will schedule a site visit for meter installation and connection to the main water supply. You'll receive updates throughout this process."
    },
    {
      question: "Who should I contact if I have problems with my water supply?",
      answer: "For any issues with your water supply such as low pressure, discoloration, or interruption, please contact our customer support through the Support Center in your account or call our customer service line at +265 1 312 755."
    },
  ];

  const filteredFaqs = faqItems.filter(item => 
    item.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Frequently Asked Questions</h1>
      <p className="text-nrwb-muted">Find answers to common questions about NRWB services</p>
      
      <div className="relative max-w-lg mb-8">
        <Search className="absolute left-3 top-3 h-4 w-4 text-nrwb-muted" />
        <Input
          placeholder="Search FAQs..."
          className="pl-10 bg-nrwb-dark/50 border-nrwb-dark"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>{searchTerm ? `Search Results (${filteredFaqs.length})` : 'Common Questions'}</CardTitle>
          <CardDescription>Click on a question to view the answer</CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {filteredFaqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-nrwb-muted">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
            {filteredFaqs.length === 0 && (
              <div className="py-4 text-center text-nrwb-muted">
                No results found for "{searchTerm}". Please try another search term.
              </div>
            )}
          </Accordion>
        </CardContent>
      </Card>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Still Have Questions?</CardTitle>
          <CardDescription>Contact our support team for assistance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4">
            <p className="mb-4 text-nrwb-muted">
              If you couldn't find the answer you're looking for, our customer support team is available to help.
            </p>
            <div className="space-y-2">
              <p><strong>Email:</strong> support@nrwb.mw</p>
              <p><strong>Phone:</strong> +265 1 312 755</p>
              <p><strong>Hours:</strong> Monday to Friday, 8:00 AM - 5:00 PM</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default FaqsPage;
