
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { AlertCircle, MessageSquare, Phone } from 'lucide-react';

const SupportPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Support Center</h1>
      <p className="text-nrwb-muted">Get help with your water service inquiries</p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-dark">
          <CardHeader className="pb-2">
            <div className="w-12 h-12 rounded-full bg-nrwb-accent/20 flex items-center justify-center mb-2">
              <MessageSquare className="h-6 w-6 text-nrwb-accent" />
            </div>
            <CardTitle>Submit a Support Ticket</CardTitle>
            <CardDescription>We'll respond to your inquiry within 24 hours</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div>
                <label htmlFor="subject" className="text-nrwb-muted text-sm">Subject</label>
                <Input id="subject" className="bg-nrwb-dark/50 border-nrwb-dark" placeholder="Brief description of your issue" />
              </div>
              <div>
                <label htmlFor="message" className="text-nrwb-muted text-sm">Message</label>
                <Textarea id="message" className="bg-nrwb-dark/50 border-nrwb-dark h-32" placeholder="Please provide details about your issue" />
              </div>
              <Button className="w-full bg-nrwb-accent hover:bg-nrwb-accent/90">Submit Ticket</Button>
            </form>
          </CardContent>
        </Card>
        
        <Card className="glass-dark">
          <CardHeader className="pb-2">
            <div className="w-12 h-12 rounded-full bg-nrwb-accent/20 flex items-center justify-center mb-2">
              <Phone className="h-6 w-6 text-nrwb-accent" />
            </div>
            <CardTitle>Contact Information</CardTitle>
            <CardDescription>Reach out to our support team directly</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="text-nrwb-muted text-sm">Customer Service</p>
                <p className="font-medium">+265 1 312 755</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Technical Support</p>
                <p className="font-medium">+265 1 312 756</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Emergencies</p>
                <p className="font-medium">+265 888 123 456</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Email</p>
                <p className="font-medium">support@nrwb.mw</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Operating Hours</p>
                <p className="font-medium">Mon-Fri: 8:00 AM - 5:00 PM</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark">
          <CardHeader className="pb-2">
            <div className="w-12 h-12 rounded-full bg-nrwb-accent/20 flex items-center justify-center mb-2">
              <AlertCircle className="h-6 w-6 text-nrwb-accent" />
            </div>
            <CardTitle>Emergency Reporting</CardTitle>
            <CardDescription>Report water leaks and service disruptions</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div>
                <label htmlFor="location" className="text-nrwb-muted text-sm">Location</label>
                <Input id="location" className="bg-nrwb-dark/50 border-nrwb-dark" placeholder="Where is the issue located?" />
              </div>
              <div>
                <label htmlFor="issue" className="text-nrwb-muted text-sm">Issue Type</label>
                <select id="issue" className="w-full h-10 px-3 rounded-md bg-nrwb-dark/50 border-nrwb-dark text-nrwb-light">
                  <option value="">Select issue type</option>
                  <option value="leak">Water Leak</option>
                  <option value="pressure">Low Water Pressure</option>
                  <option value="quality">Water Quality Issue</option>
                  <option value="meter">Meter Damage</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div>
                <label htmlFor="emergency-details" className="text-nrwb-muted text-sm">Details</label>
                <Textarea id="emergency-details" className="bg-nrwb-dark/50 border-nrwb-dark h-20" placeholder="Please describe the emergency" />
              </div>
              <Button className="w-full bg-red-500 hover:bg-red-600">Report Emergency</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default SupportPage;
