
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const PaymentsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Payment History</h1>
      <p className="text-nrwb-muted">View and manage your payment transactions</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Payment Records</CardTitle>
          <CardDescription>Your payment history with Northern Region Water Board</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-8 text-center">
            <p className="text-nrwb-muted">No payment records found.</p>
            <p className="text-sm text-nrwb-muted mt-2">
              Once you make payments for your water services or connection fees, they will appear here.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PaymentsPage;
