
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

const ProfilePage: React.FC = () => {
  const { user } = useAuth();
  
  const handleUpdateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Profile updated successfully!");
  };
  
  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Password changed successfully!");
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Profile Settings</h1>
      <p className="text-nrwb-muted">Manage your account settings and preferences</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>Account Information</CardTitle>
            <CardDescription>View and update your account details</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user?.avatar} />
              <AvatarFallback>{user?.firstName.charAt(0)}{user?.lastName.charAt(0)}</AvatarFallback>
            </Avatar>
            <h3 className="text-xl font-medium mt-4">{user?.firstName} {user?.lastName}</h3>
            <p className="text-nrwb-muted">{user?.email}</p>
            <p className="text-nrwb-accent text-sm mt-1 capitalize">{user?.role}</p>
            
            <div className="w-full mt-6 space-y-3">
              <div className="flex justify-between">
                <span className="text-nrwb-muted">Account ID</span>
                <span>{user?.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-nrwb-muted">Username</span>
                <span>{user?.username}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-nrwb-muted">Last Login</span>
                <span>Today, 10:35 AM</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark lg:col-span-2">
          <CardHeader>
            <CardTitle>Update Profile</CardTitle>
            <CardDescription>Change your personal information</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="firstName" className="text-nrwb-muted text-sm">First Name</label>
                  <Input id="firstName" className="bg-nrwb-dark/50 border-nrwb-dark" defaultValue={user?.firstName} />
                </div>
                <div>
                  <label htmlFor="lastName" className="text-nrwb-muted text-sm">Last Name</label>
                  <Input id="lastName" className="bg-nrwb-dark/50 border-nrwb-dark" defaultValue={user?.lastName} />
                </div>
              </div>
              <div>
                <label htmlFor="email" className="text-nrwb-muted text-sm">Email</label>
                <Input id="email" className="bg-nrwb-dark/50 border-nrwb-dark" defaultValue={user?.email} type="email" />
              </div>
              <div>
                <label htmlFor="phone" className="text-nrwb-muted text-sm">Phone Number</label>
                <Input id="phone" className="bg-nrwb-dark/50 border-nrwb-dark" placeholder="+265" />
              </div>
              <div>
                <label htmlFor="address" className="text-nrwb-muted text-sm">Address</label>
                <Input id="address" className="bg-nrwb-dark/50 border-nrwb-dark" placeholder="Your residential address" />
              </div>
              <div className="pt-4">
                <Button type="submit" className="bg-nrwb-accent hover:bg-nrwb-accent/90">Save Changes</Button>
              </div>
            </form>
          </CardContent>
        </Card>
        
        <Card className="glass-dark lg:col-span-3">
          <CardHeader>
            <CardTitle>Change Password</CardTitle>
            <CardDescription>Update your account password</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              <div>
                <label htmlFor="currentPassword" className="text-nrwb-muted text-sm">Current Password</label>
                <Input id="currentPassword" className="bg-nrwb-dark/50 border-nrwb-dark" type="password" />
              </div>
              <div>
                <label htmlFor="newPassword" className="text-nrwb-muted text-sm">New Password</label>
                <Input id="newPassword" className="bg-nrwb-dark/50 border-nrwb-dark" type="password" />
              </div>
              <div>
                <label htmlFor="confirmPassword" className="text-nrwb-muted text-sm">Confirm New Password</label>
                <Input id="confirmPassword" className="bg-nrwb-dark/50 border-nrwb-dark" type="password" />
              </div>
              <div className="pt-4">
                <Button type="submit" className="bg-nrwb-accent hover:bg-nrwb-accent/90">Update Password</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ProfilePage;
