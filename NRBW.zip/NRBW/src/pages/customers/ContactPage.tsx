
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Mail, Clock, Globe } from 'lucide-react';
import { toast } from 'sonner';

const ContactPage: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Your message has been sent. We'll respond shortly!");
  };
  
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Contact NRWB</h1>
      <p className="text-nrwb-muted">Get in touch with our team for any inquiries or assistance</p>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="glass-dark lg:col-span-1">
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
            <CardDescription>Reach out through any of these channels</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center mr-4">
                <MapPin className="h-5 w-5 text-nrwb-accent" />
              </div>
              <div>
                <h3 className="font-medium">Headquarters</h3>
                <p className="text-nrwb-muted text-sm mt-1">
                  NRWB House, Mzuzu City<br />
                  P.O. Box 1395<br />
                  Mzuzu, Malawi
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center mr-4">
                <Phone className="h-5 w-5 text-nrwb-accent" />
              </div>
              <div>
                <h3 className="font-medium">Phone Numbers</h3>
                <p className="text-nrwb-muted text-sm mt-1">
                  Customer Service: +265 1 312 755<br />
                  Technical Support: +265 1 312 756<br />
                  Toll Free: 0800 123 456
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center mr-4">
                <Mail className="h-5 w-5 text-nrwb-accent" />
              </div>
              <div>
                <h3 className="font-medium">Email Addresses</h3>
                <p className="text-nrwb-muted text-sm mt-1">
                  General Inquiries: info@nrwb.mw<br />
                  Customer Support: support@nrwb.mw<br />
                  Billing Department: billing@nrwb.mw
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center mr-4">
                <Clock className="h-5 w-5 text-nrwb-accent" />
              </div>
              <div>
                <h3 className="font-medium">Operating Hours</h3>
                <p className="text-nrwb-muted text-sm mt-1">
                  Monday - Friday: 8:00 AM - 5:00 PM<br />
                  Saturday: 8:00 AM - 12:00 PM<br />
                  Sunday & Holidays: Closed<br />
                  <span className="text-nrwb-accent">24/7 Emergency Support Available</span>
                </p>
              </div>
            </div>
            
            <div className="flex items-start">
              <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center mr-4">
                <Globe className="h-5 w-5 text-nrwb-accent" />
              </div>
              <div>
                <h3 className="font-medium">Social Media</h3>
                <p className="text-nrwb-muted text-sm mt-1">
                  Facebook: /NorthernRegionWaterBoard<br />
                  Twitter: @NRWB_Malawi<br />
                  Instagram: @nrwb_official
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark lg:col-span-2">
          <CardHeader>
            <CardTitle>Send Us a Message</CardTitle>
            <CardDescription>Fill out the form below and we'll respond as soon as possible</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="text-nrwb-muted text-sm">Full Name</label>
                  <Input id="name" className="bg-nrwb-dark/50 border-nrwb-dark" required />
                </div>
                <div>
                  <label htmlFor="email" className="text-nrwb-muted text-sm">Email Address</label>
                  <Input id="email" type="email" className="bg-nrwb-dark/50 border-nrwb-dark" required />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="phone" className="text-nrwb-muted text-sm">Phone Number</label>
                  <Input id="phone" className="bg-nrwb-dark/50 border-nrwb-dark" />
                </div>
                <div>
                  <label htmlFor="subject" className="text-nrwb-muted text-sm">Subject</label>
                  <Input id="subject" className="bg-nrwb-dark/50 border-nrwb-dark" required />
                </div>
              </div>
              
              <div>
                <label htmlFor="message" className="text-nrwb-muted text-sm">Message</label>
                <Textarea 
                  id="message" 
                  className="bg-nrwb-dark/50 border-nrwb-dark min-h-[150px]" 
                  placeholder="Please provide details of your inquiry..."
                  required
                />
              </div>
              
              <div className="pt-2">
                <Button type="submit" className="bg-nrwb-accent hover:bg-nrwb-accent/90">Send Message</Button>
              </div>
            </form>
          </CardContent>
        </Card>
        
        <Card className="glass-dark lg:col-span-3">
          <CardHeader>
            <CardTitle>Regional Offices</CardTitle>
            <CardDescription>Visit us at any of our locations across the Northern Region</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Mzuzu Main Office</h3>
                <p className="text-sm text-nrwb-muted">
                  NRWB House, Main Street<br />
                  Mzuzu City<br />
                  Phone: +265 1 312 755<br />
                  Email: mzuzu@nrwb.mw
                </p>
              </div>
              
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Nkhata Bay Office</h3>
                <p className="text-sm text-nrwb-muted">
                  Harbor Complex<br />
                  Nkhata Bay<br />
                  Phone: +265 1 352 476<br />
                  Email: nkhatabad@nrwb.mw
                </p>
              </div>
              
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Rumphi Office</h3>
                <p className="text-sm text-nrwb-muted">
                  Boma Road<br />
                  Rumphi<br />
                  Phone: +265 1 372 166<br />
                  Email: rumphi@nrwb.mw
                </p>
              </div>
              
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Karonga Office</h3>
                <p className="text-sm text-nrwb-muted">
                  Main District Road<br />
                  Karonga<br />
                  Phone: +265 1 362 288<br />
                  Email: karonga@nrwb.mw
                </p>
              </div>
              
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Chitipa Office</h3>
                <p className="text-sm text-nrwb-muted">
                  District Center<br />
                  Chitipa<br />
                  Phone: +265 1 382 199<br />
                  Email: chitipa@nrwb.mw
                </p>
              </div>
              
              <div className="p-4 bg-nrwb-dark/30 rounded-lg">
                <h3 className="font-bold mb-2">Mzimba Office</h3>
                <p className="text-sm text-nrwb-muted">
                  Mzimba Boma<br />
                  Mzimba<br />
                  Phone: +265 1 342 355<br />
                  Email: mzimba@nrwb.mw
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ContactPage;
