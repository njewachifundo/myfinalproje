
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const LandingPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="py-4 px-6 flex items-center justify-between glass">
        <div className="flex items-center gap-2">
          <div className="text-white">
            <span className="font-bold ">NRWB</span>
          </div>
                 </div>
        <div className="flex items-center gap-4">
          <Button asChild variant="ghost" className="text-nrwb-light hover:text-nrwb-accent">
            <Link to="/login">Login</Link>
          </Button>
          <Button asChild className="bg-nrwb-accent hover:bg-nrwb-accent/90 text-white">
            <Link to="/register">Register</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1">
        <section className="py-20 px-6">
          <div className="max-w-5xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
              Water Connection <span className="text-nrwb-accent">Made Simple</span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-nrwb-muted max-w-3xl mx-auto">
              Apply for new water connections, track your application status, and manage payments all in one place.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-nrwb-accent hover:bg-nrwb-accent/90 text-white text-lg px-8 py-6">
                <Link to="/register">Get Started <ArrowRight className="ml-2 h-5 w-5" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="border-nrwb-accent text-nrwb-accent hover:bg-nrwb-accent/10 text-lg px-8 py-6">
                <Link to="/learn-more">Learn More</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 px-6 bg-nrwb-dark/30">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center text-shadow">
              How It <span className="text-nrwb-accent">Works</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  step: '01',
                  title: 'Create Account',
                  description: 'Register with your details to access our services and application forms.',
                },
                {
                  step: '02',
                  title: 'Submit Application',
                  description: 'Fill out the application form with your property details and required documents.',
                },
                {
                  step: '03',
                  title: 'Track Progress',
                  description: 'Track your application status in real-time and receive updates at every step.',
                },
              ].map((item, index) => (
                <div key={index} className="glass p-6 rounded-xl relative overflow-hidden group">
                  <span className="absolute -top-5 -right-5 text-8xl font-bold opacity-10 group-hover:opacity-20 transition-opacity text-nrwb-accent">
                    {item.step}
                  </span>
                  <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                  <p className="text-nrwb-muted">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold mb-12 text-center text-shadow">
              Our <span className="text-nrwb-accent">Services</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: "🏠",
                  title: "New Connections",
                  description: "Apply for new water connections for residential or commercial properties.",
                },
                {
                  icon: "📱",
                  title: "Online Tracking",
                  description: "Track your application status online without visiting our offices.",
                },
                {
                  icon: "💳",
                  title: "Flexible Payments",
                  description: "Pay for services using multiple payment methods securely online.",
                },
                {
                  icon: "📞",
                  title: "24/7 Support",
                  description: "Get assistance anytime through our dedicated support channels.",
                },
              ].map((service, index) => (
                <div 
                  key={index} 
                  className="neumorphic p-6 flex flex-col items-center text-center transition-transform hover:-translate-y-1"
                >
                  <span className="text-4xl mb-4">{service.icon}</span>
                  <h3 className="text-lg font-semibold mb-2">{service.title}</h3>
                  <p className="text-sm text-nrwb-muted">{service.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <footer className="py-8 px-6 bg-nrwb-dark/50 glass">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Northern Region Water Board</h3>
            <p className="text-nrwb-muted mb-4">
              Providing clean and safe water to the Northern Region of Malawi.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-nrwb-muted">
              <li><Link to="/about" className="hover:text-nrwb-accent transition-colors">About Us</Link></li>
              <li><Link to="/services" className="hover:text-nrwb-accent transition-colors">Our Services</Link></li>
              <li><Link to="/faqs" className="hover:text-nrwb-accent transition-colors">FAQs</Link></li>
              <li><Link to="/contact" className="hover:text-nrwb-accent transition-colors">Contact Us</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Contact Information</h4>
            <address className="text-nrwb-muted not-italic">
              <p>123 Water Street</p>
              <p>Mzuzu, Malawi</p>
              <p className="mt-2">Email: info@nrwb.mw</p>
              <p>Phone: +265 123 4567</p>
            </address>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-8 pt-4 border-t border-white/10 text-center">
          <p className="text-sm text-nrwb-muted">
            © {new Date().getFullYear()} Northern Region Water Board. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
