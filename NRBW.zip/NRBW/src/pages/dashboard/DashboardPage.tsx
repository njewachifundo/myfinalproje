
import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import CustomerDashboard from './CustomerDashboard';
import StaffDashboard from './StaffDashboard';
import AdminDashboard from './AdminDashboard';
import ManagementDashboard from './ManagementDashboard';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  
  // Render the appropriate dashboard based on user role
  if (!user) {
    return <div>Loading...</div>;
  }
  
  switch (user.role) {
    case 'staff':
      return <StaffDashboard />;
    case 'admin':
      return <AdminDashboard />;
    case 'management':
      return <ManagementDashboard />;
    case 'customer':
    default:
      return <CustomerDashboard />;
  }
};

export default DashboardPage;
