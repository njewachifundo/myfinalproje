
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Users, DollarSign, AlertCircle, BarChart2, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const StaffDashboard: React.FC = () => {
  // Mock data for the staff dashboard
  const pendingApplications = [
    { id: 'NRWB-2023-00457', name: 'John Magola', date: '2023-05-10', status: 'Technical Review', priority: 'medium' },
    { id: 'NRWB-2023-00458', name: 'Janesi phikani', date: '2023-05-11', status: 'Document Verification', priority: 'high' },
    { id: 'NRWB-2023-00459', name: 'Robert ngozo', date: '2023-05-12', status: 'Initial Assessment', priority: 'low' },
    { id: 'NRWB-2023-00460', name: 'Mary Wanjiru', date: '2023-05-13', status: 'Payment Pending', priority: 'medium' },
  ];
  
  const supportTickets = [
    { id: 'TKT-2023-001', issue: 'Meter Reading Dispute', customer: 'David Kalonga', date: '2023-05-13', status: 'Open' },
    { id: 'TKT-2023-002', issue: 'Billing Inquiry', customer: 'Sarah Chirwa', date: '2023-05-12', status: 'In Progress' },
    { id: 'TKT-2023-003', issue: 'Water Quality Concern', customer: 'Thomas Tembo', date: '2023-05-10', status: 'On Hold' },
  ];
  
  const applicationData = [
    { month: 'Jan', applications: 65 },
    { month: 'Feb', applications: 59 },
    { month: 'Mar', applications: 80 },
    { month: 'Apr', applications: 81 },
    { month: 'May', applications: 56 },
    { month: 'Jun', applications: 55 },
  ];
  
  const revenueData = [
    { month: 'Jan', revenue: 2400 },
    { month: 'Feb', revenue: 1398 },
    { month: 'Mar', revenue: 9800 },
    { month: 'Apr', revenue: 3908 },
    { month: 'May', revenue: 4800 },
    { month: 'Jun', revenue: 3800 },
  ];

  const quickLinks = [
    { name: 'New Applications', count: 12, icon: FileText, url: '/application-management' },
    { name: 'Customer Records', count: 1243, icon: Users, url: '/customer-management' },
    { name: 'Pending Payments', count: 8, icon: DollarSign, url: '/payment-processing' },
    { name: 'Support Tickets', count: 5, icon: AlertCircle, url: '/support-tickets' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-nrwb-light">Staff Dashboard</h1>
        <p className="text-nrwb-muted mt-1">Overview of applications, customer support, and system status</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickLinks.map((link, index) => (
          <Card key={index} className="neumorphic hover:-translate-y-1 transition-transform">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center">
                    <link.icon className="h-5 w-5 text-nrwb-accent" />
                  </div>
                  <div>
                    <p className="text-nrwb-muted text-xs">{link.name}</p>
                    <p className="text-2xl font-bold">{link.count}</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" asChild>
                  <Link to={link.url}>
                    <ChevronRight className="h-5 w-5 text-nrwb-muted" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>Pending Applications</CardTitle>
            <CardDescription>Applications requiring attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingApplications.map((application) => (
                <div key={application.id} className="p-4 bg-nrwb-dark/30 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">{application.id}</h4>
                      <p className="text-sm text-nrwb-muted">{application.name}</p>
                    </div>
                    <Badge className={`${
                      application.priority === 'high' ? 'bg-red-500/20 text-red-500' :
                      application.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-500' :
                      'bg-green-500/20 text-green-500'
                    }`}>
                      {application.priority.toUpperCase()}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-nrwb-muted">{application.date}</p>
                    <p className="text-xs font-medium text-nrwb-accent">{application.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/application-management">View All Applications</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>Support Tickets</CardTitle>
            <CardDescription>Recent customer support inquiries</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {supportTickets.map((ticket) => (
                <div key={ticket.id} className="p-4 bg-nrwb-dark/30 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">{ticket.issue}</h4>
                      <p className="text-sm text-nrwb-muted">{ticket.customer}</p>
                    </div>
                    <Badge className={`${
                      ticket.status === 'Open' ? 'bg-blue-500/20 text-blue-500' :
                      ticket.status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-500' :
                      'bg-purple-500/20 text-purple-500'
                    }`}>
                      {ticket.status}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <p className="text-xs text-nrwb-muted">{ticket.id}</p>
                    <p className="text-xs font-medium text-nrwb-muted">{ticket.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/support-tickets">View All Support Tickets</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-dark">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart2 className="h-5 w-5 mr-2" />
              Application Trends
            </CardTitle>
            <CardDescription>Monthly application submissions</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={applicationData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                    itemStyle={{ color: '#E5E7EB' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="applications" 
                    stroke="#10B981" 
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-dark">
          <CardHeader>
            <CardTitle className="flex items-center">
              <DollarSign className="h-5 w-5 mr-2" />
              Revenue Overview
            </CardTitle>
            <CardDescription>Monthly revenue from new connections</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                    itemStyle={{ color: '#E5E7EB' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="#3B82F6" 
                    activeDot={{ r: 8 }} 
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default StaffDashboard;
