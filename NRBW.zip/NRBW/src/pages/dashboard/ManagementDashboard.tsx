
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { LineChart, TrendingUp, PieChart as PieChartIcon, Banknote } from 'lucide-react';
import { Link } from 'react-router-dom';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart as RechartsLineChart,
  Line,
  PieChart,
  Pie,
  Cell
} from 'recharts';

const ManagementDashboard: React.FC = () => {
  // Mock data for management dashboard
  const revenueData = [
    { month: 'Jan', actual: 4000, projected: 3000 },
    { month: 'Feb', actual: 3000, projected: 3100 },
    { month: 'Mar', actual: 5000, projected: 3200 },
    { month: 'Apr', actual: 4500, projected: 3300 },
    { month: 'May', actual: 6000, projected: 3400 },
    { month: 'Jun', actual: 5500, projected: 3500 },
  ];

  const performanceMetrics = [
    { name: 'Processing Time', current: 3.2, target: 2.5, unit: 'days' },
    { name: 'Customer Satisfaction', current: 87, target: 90, unit: '%' },
    { name: 'Connection Success Rate', current: 94.5, target: 98, unit: '%' },
    { name: 'Revenue per Connection', current: 56000, target: 60000, unit: 'MWK' },
  ];
  
  const applicationDistribution = [
    { name: 'Residential', value: 68 },
    { name: 'Commercial', value: 22 },
    { name: 'Industrial', value: 7 },
    { name: 'Institutional', value: 3 },
  ];
  
  const COLORS = ['#10B981', '#3B82F6', '#EC4899', '#F59E0B'];
  
  const regionalData = [
    { region: 'Mzuzu Central', connections: 120, revenue: 7200000 },
    { region: 'Mzuzu North', connections: 85, revenue: 5100000 },
    { region: 'Mzuzu South', connections: 95, revenue: 5700000 },
    { region: 'Ekwendeni', connections: 45, revenue: 2700000 },
    { region: 'Nkhata Bay', connections: 55, revenue: 3300000 },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-nrwb-light">Executive Dashboard</h1>
        <p className="text-nrwb-muted mt-1">Strategic overview, performance metrics, and financial insights</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass-dark">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <p className="text-nrwb-muted text-sm">Revenue (MTD)</p>
                <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
                  <Banknote className="h-4 w-4 text-green-500" />
                </div>
              </div>
              <h2 className="text-2xl font-bold">MK 22.4M</h2>
              <p className="text-green-500 text-sm flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +12.5% from last month
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <p className="text-nrwb-muted text-sm">New Connections (MTD)</p>
                <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <LineChart className="h-4 w-4 text-blue-500" />
                </div>
              </div>
              <h2 className="text-2xl font-bold">145</h2>
              <p className="text-green-500 text-sm flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1" />
                +8.2% from last month
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <p className="text-nrwb-muted text-sm">Avg. Processing Time</p>
                <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                  <TrendingUp className="h-4 w-4 text-purple-500" />
                </div>
              </div>
              <h2 className="text-2xl font-bold">3.2 days</h2>
              <p className="text-red-500 text-sm flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 rotate-180" />
                +0.5 days from target
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass-dark">
          <CardContent className="p-6">
            <div className="flex flex-col">
              <div className="flex items-center justify-between mb-2">
                <p className="text-nrwb-muted text-sm">Customer Satisfaction</p>
                <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
                  <PieChartIcon className="h-4 w-4 text-yellow-500" />
                </div>
              </div>
              <h2 className="text-2xl font-bold">87%</h2>
              <p className="text-red-500 text-sm flex items-center mt-1">
                <TrendingUp className="h-3 w-3 mr-1 rotate-180" />
                -3% from target
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>Revenue Trends</CardTitle>
            <CardDescription>Actual vs projected revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#6B7280" />
                  <YAxis stroke="#6B7280" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }} 
                    itemStyle={{ color: '#E5E7EB' }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="actual" 
                    name="Actual Revenue"
                    stroke="#10B981" 
                    activeDot={{ r: 8 }} 
                    strokeWidth={2}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="projected" 
                    name="Projected Revenue"
                    stroke="#6B7280" 
                    strokeDasharray="5 5" 
                  />
                </RechartsLineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/financial">View Financial Reports</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>Application Distribution</CardTitle>
            <CardDescription>Connection types breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={applicationDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {applicationDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Performance Metrics</CardTitle>
          <CardDescription>Key performance indicators vs targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={performanceMetrics}
                layout="vertical"
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" horizontal={false} />
                <XAxis type="number" stroke="#6B7280" />
                <YAxis dataKey="name" type="category" stroke="#6B7280" width={150} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151' }}
                  itemStyle={{ color: '#E5E7EB' }}
                  formatter={(value, name) => {
                    const metric = performanceMetrics.find(m => m.current === value || m.target === value);
                    return [`${value} ${metric?.unit}`, name];
                  }}
                />
                <Legend />
                <Bar dataKey="current" name="Current" fill="#3B82F6" />
                <Bar dataKey="target" name="Target" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
            <Link to="/performance-analytics">View Detailed Performance Analytics</Link>
          </Button>
        </CardFooter>
      </Card>

      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Regional Performance</CardTitle>
          <CardDescription>Connections and revenue by region</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-nrwb-muted border-b border-nrwb-dark">
                  <th className="text-left py-3 px-4">Region</th>
                  <th className="text-center py-3 px-4">New Connections</th>
                  <th className="text-center py-3 px-4">Revenue (MK)</th>
                  <th className="text-center py-3 px-4">Avg. per Connection</th>
                </tr>
              </thead>
              <tbody>
                {regionalData.map((region) => (
                  <tr key={region.region} className="border-b border-nrwb-dark/50">
                    <td className="py-3 px-4 font-medium">{region.region}</td>
                    <td className="py-3 px-4 text-center">{region.connections}</td>
                    <td className="py-3 px-4 text-center">{region.revenue.toLocaleString()}</td>
                    <td className="py-3 px-4 text-center">
                      {Math.round(region.revenue / region.connections).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
            <Link to="/resource-allocation">View Resource Allocation</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ManagementDashboard;
