
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Shield, FileDigit, Database, Webhook, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  PieChart,
  Pie,
  Cell,
  Legend,
  ResponsiveContainer
} from 'recharts';

const AdminDashboard: React.FC = () => {
  // Mock data for admin dashboard
  const systemStatus = {
    uptime: '99.98%',
    serverLoad: 42,
    databaseSize: '1.2 TB',
    activeSessions: 143,
    lastBackup: '2023-05-14 03:00 AM',
    apiRequests: '2.4K/day',
  };
  
  const userDistribution = [
    { name: 'Customers', value: 1243 },
    { name: 'Staff', value: 84 },
    { name: 'Admin', value: 12 },
    { name: 'Management', value: 6 },
  ];
  
  const COLORS = ['#10B981', '#3B82F6', '#EC4899', '#F59E0B'];
  
  const recentLogs = [
    { id: 'LOG-2023-001', action: 'User Login', user: 'sarah.j@nrwb.mw', date: '2023-05-14 10:23:45', status: 'Success' },
    { id: 'LOG-2023-002', action: 'Database Backup', user: 'system', date: '2023-05-14 03:00:00', status: 'Success' },
    { id: 'LOG-2023-003', action: 'User Permission Change', user: 'admin@nrwb.mw', date: '2023-05-13 16:45:22', status: 'Success' },
    { id: 'LOG-2023-004', action: 'API Integration Update', user: 'developer@nrwb.mw', date: '2023-05-13 13:12:08', status: 'Warning' },
    { id: 'LOG-2023-005', action: 'Failed Login Attempt', user: 'unknown', date: '2023-05-13 08:54:31', status: 'Error' },
  ];

  const quickLinks = [
    { name: 'User Management', count: 1345, icon: Users, url: '/user-management' },
    { name: 'Security', count: 3, icon: Shield, url: '/security' },
    { name: 'Audit Logs', count: 1452, icon: FileDigit, url: '/audit-logs' },
    { name: 'Backup & Restore', count: 24, icon: Database, url: '/backup' },
    { name: 'API Integration', count: 8, icon: Webhook, url: '/api-integration' },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-nrwb-light">Admin Dashboard</h1>
        <p className="text-nrwb-muted mt-1">System overview, security status, and user management</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
        {quickLinks.map((link, index) => (
          <Card key={index} className="neumorphic hover:-translate-y-1 transition-transform">
            <CardContent className="p-4">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-nrwb-accent/20 flex items-center justify-center mb-3">
                  <link.icon className="h-6 w-6 text-nrwb-accent" />
                </div>
                <p className="text-sm font-medium">{link.name}</p>
                <p className="text-xl font-bold mt-1">{link.count}</p>
                <Button variant="ghost" size="sm" asChild className="mt-2">
                  <Link to={link.url}>
                    <span className="flex items-center">View <ChevronRight className="h-4 w-4 ml-1" /></span>
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Current system metrics and performance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-nrwb-muted text-sm">Uptime</p>
                <p className="font-medium">{systemStatus.uptime}</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Active Sessions</p>
                <p className="font-medium">{systemStatus.activeSessions}</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Database Size</p>
                <p className="font-medium">{systemStatus.databaseSize}</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Last Backup</p>
                <p className="font-medium">{systemStatus.lastBackup}</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">API Requests</p>
                <p className="font-medium">{systemStatus.apiRequests}</p>
              </div>
              <div>
                <p className="text-nrwb-muted text-sm">Server Load</p>
                <div className="flex items-center gap-2">
                  <Progress 
                    value={systemStatus.serverLoad} 
                    className="h-2 bg-nrwb-dark flex-1" 
                  />
                  <span className="text-xs">{systemStatus.serverLoad}%</span>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/system-config">View System Configuration</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="glass-dark">
          <CardHeader>
            <CardTitle>User Distribution</CardTitle>
            <CardDescription>Breakdown of system user types</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={userDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {userDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/user-management">Manage Users</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Audit Logs</CardTitle>
          <CardDescription>Recent system activities and events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-nrwb-muted border-b border-nrwb-dark">
                  <th className="text-left py-3 px-4">Log ID</th>
                  <th className="text-left py-3 px-4">Action</th>
                  <th className="text-left py-3 px-4">User</th>
                  <th className="text-left py-3 px-4">Date & Time</th>
                  <th className="text-left py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody>
                {recentLogs.map((log) => (
                  <tr key={log.id} className="border-b border-nrwb-dark/50">
                    <td className="py-3 px-4 font-mono text-xs">{log.id}</td>
                    <td className="py-3 px-4">{log.action}</td>
                    <td className="py-3 px-4">{log.user}</td>
                    <td className="py-3 px-4 text-nrwb-muted">{log.date}</td>
                    <td className="py-3 px-4">
                      <Badge className={`${
                        log.status === 'Success' ? 'bg-green-500/20 text-green-500' : 
                        log.status === 'Warning' ? 'bg-yellow-500/20 text-yellow-500' :
                        'bg-red-500/20 text-red-500'
                      }`}>
                        {log.status}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
        <CardFooter>
          <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
            <Link to="/audit-logs">View All Audit Logs</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminDashboard;
