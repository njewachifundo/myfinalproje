
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, FileSearch, AlertCircle, Bell, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';

const CustomerDashboard: React.FC = () => {
  // Mock data for the customer dashboard
  const applicationStatus = {
    stage: 'Technical Review',
    progress: 60,
    lastUpdate: '2023-05-10',
    applicationNumber: 'NRWB-2023-00457',
    messages: 2,
  };

  const notifications = [
    {
      id: 1,
      title: 'Document Verification Complete',
      message: 'Your submitted documents have been verified successfully.',
      time: '2 hours ago',
      read: false,
    },
    {
      id: 2,
      title: 'Technical Review Started',
      message: 'Your application is now under technical review by our team.',
      time: '1 day ago',
      read: true,
    },
    {
      id: 3,
      title: 'Quote Generation Complete',
      message: 'Connection quote has been generated and is ready for review.',
      time: '3 days ago',
      read: true,
    },
  ];

  const announcements = [
    {
      id: 1,
      title: 'Scheduled Maintenance Notice',
      message: 'There will be a scheduled water supply interruption in Mzuzu Central area on May 15th from 10:00 AM to 4:00 PM.',
      date: 'May 12, 2023',
    },
    {
      id: 2,
      title: 'New Payment Method Available',
      message: 'We have added support for Mobile Money payments through TNM and Airtel.',
      date: 'May 5, 2023',
    },
  ];

  const quickLinks = [
    { name: 'Start New Application', icon: FileText, url: '/application/new' },
    { name: 'Check Application Status', icon: FileSearch, url: '/application/status' },
    { name: 'Report an Issue', icon: AlertCircle, url: '/support' },
    { name: 'View Payment History', icon: Bell, url: '/payments' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-nrwb-light">Welcome Back, John</h1>
          <p className="text-nrwb-muted mt-1">Here's an overview of your application and account</p>
        </div>
        <Button asChild className="mt-4 md:mt-0 bg-nrwb-accent hover:bg-nrwb-accent/90">
          <Link to="/application/new">New Connection Application</Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {quickLinks.map((link, index) => (
          <Card key={index} className="neumorphic hover:-translate-y-1 transition-transform">
            <CardContent className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-nrwb-accent/20 flex items-center justify-center">
                  <link.icon className="h-5 w-5 text-nrwb-accent" />
                </div>
                <span className="font-medium">{link.name}</span>
              </div>
              <Button variant="ghost" size="icon" asChild>
                <Link to={link.url}>
                  <ChevronRight className="h-5 w-5 text-nrwb-muted" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 glass-dark">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Active Application</CardTitle>
              <CardDescription>Current status and timeline</CardDescription>
            </div>
            <Badge className="bg-nrwb-accent/20 text-nrwb-accent hover:bg-nrwb-accent/30">
              {applicationStatus.stage}
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-nrwb-muted">Application Progress</span>
                <span className="text-nrwb-accent">{applicationStatus.progress}%</span>
              </div>
              <Progress value={applicationStatus.progress} className="h-2 bg-nrwb-dark" />
            </div>
            
            <div className="bg-nrwb-dark/50 rounded-lg p-4 grid grid-cols-2 gap-4">
              <div>
                <div className="text-nrwb-muted text-sm">Application Number</div>
                <div className="font-medium">{applicationStatus.applicationNumber}</div>
              </div>
              <div>
                <div className="text-nrwb-muted text-sm">Last Updated</div>
                <div className="font-medium">{applicationStatus.lastUpdate}</div>
              </div>
              <div>
                <div className="text-nrwb-muted text-sm">Next Step</div>
                <div className="font-medium">Site Assessment</div>
              </div>
              <div>
                <div className="text-nrwb-muted text-sm">Estimated Completion</div>
                <div className="font-medium">June 15, 2023</div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" className="w-full border-nrwb-accent/50 text-nrwb-accent hover:bg-nrwb-accent/10">
              <Link to="/application/status">View Detailed Status</Link>
            </Button>
          </CardFooter>
        </Card>

        <Card className="glass-dark">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Notifications</span>
              <Badge className="bg-nrwb-accent text-white">{notifications.filter(n => !n.read).length}</Badge>
            </CardTitle>
            <CardDescription>Recent updates and messages</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4 max-h-[300px] overflow-y-auto hide-scrollbar">
            {notifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`p-3 rounded-lg ${notification.read ? 'bg-nrwb-dark/30' : 'bg-nrwb-accent/10 border-l-2 border-nrwb-accent'}`}
              >
                <div className="flex items-start justify-between">
                  <h4 className="font-medium">{notification.title}</h4>
                  {!notification.read && (
                    <div className="h-2 w-2 rounded-full bg-nrwb-accent"></div>
                  )}
                </div>
                <p className="text-sm text-nrwb-muted mt-1">{notification.message}</p>
                <div className="text-xs text-nrwb-muted/70 mt-2">{notification.time}</div>
              </div>
            ))}
          </CardContent>
          <CardFooter>
            <Button asChild variant="ghost" className="w-full text-nrwb-muted hover:text-nrwb-light">
              <Link to="/notifications">View All Notifications</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Service Announcements</CardTitle>
          <CardDescription>Important updates from NRWB</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {announcements.map((announcement) => (
              <div key={announcement.id} className="p-4 bg-nrwb-dark/30 rounded-lg">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold">{announcement.title}</h4>
                  <span className="text-xs text-nrwb-muted">{announcement.date}</span>
                </div>
                <p className="text-sm text-nrwb-muted mt-2">{announcement.message}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerDashboard;
