
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const GisMonitoringPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">GIS Monitoring</h1>
      <p className="text-nrwb-muted">Geographic information system for water infrastructure</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>GIS Monitoring System</CardTitle>
          <CardDescription>Map-based visualization of water infrastructure</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays GIS monitoring tools for NRWB staff.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default GisMonitoringPage;
