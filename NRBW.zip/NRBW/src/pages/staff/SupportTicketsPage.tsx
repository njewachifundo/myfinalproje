
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const SupportTicketsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Support Tickets</h1>
      <p className="text-nrwb-muted">Manage customer support inquiries</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Support Ticket System</CardTitle>
          <CardDescription>Respond to and resolve customer inquiries</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays support ticket management tools for NRWB staff.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SupportTicketsPage;
