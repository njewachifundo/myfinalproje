
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const ReportsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Reports & Analytics</h1>
      <p className="text-nrwb-muted">Generate and view system reports</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Reporting System</CardTitle>
          <CardDescription>Access operational reports and analytics</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays reporting tools for NRWB staff.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsPage;
