
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const SettingsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">System Settings</h1>
      <p className="text-nrwb-muted">Configure system parameters</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Settings Management</CardTitle>
          <CardDescription>Adjust operational parameters and configurations</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays system settings for NRWB staff.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsPage;
