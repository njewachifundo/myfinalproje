
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const CustomerManagementPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Customer Management</h1>
      <p className="text-nrwb-muted">View and manage customer records</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Customer Database</CardTitle>
          <CardDescription>Access and update customer information</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays customer management tools for NRWB staff.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default CustomerManagementPage;
