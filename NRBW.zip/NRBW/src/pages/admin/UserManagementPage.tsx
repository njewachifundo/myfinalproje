
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const UserManagementPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">User Management</h1>
      <p className="text-nrwb-muted">Administer system users and permissions</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>User Administration</CardTitle>
          <CardDescription>Manage user accounts and access levels</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays user management tools for NRWB administrators.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagementPage;
