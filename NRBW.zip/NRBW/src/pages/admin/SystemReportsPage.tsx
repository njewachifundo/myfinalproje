
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const SystemReportsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">System Reports</h1>
      <p className="text-nrwb-muted">Access system-wide reports and analytics</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>System Analytics</CardTitle>
          <CardDescription>Generate and view comprehensive system reports</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays system reporting tools for NRWB administrators.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemReportsPage;
