
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const BackupPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Backup & Restore</h1>
      <p className="text-nrwb-muted">Manage system backups and data restoration</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Data Backup System</CardTitle>
          <CardDescription>Configure backup schedules and restore data</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays backup and restore tools for NRWB administrators.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default BackupPage;
