
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const SystemConfigPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">System Configuration</h1>
      <p className="text-nrwb-muted">Configure system-wide settings</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>System Parameters</CardTitle>
          <CardDescription>Adjust global configuration settings</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays system configuration tools for NRWB administrators.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default SystemConfigPage;
