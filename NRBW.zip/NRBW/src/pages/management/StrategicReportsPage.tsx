
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const StrategicReportsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Strategic Reports</h1>
      <p className="text-nrwb-muted">Access high-level strategic insights</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Strategic Analysis</CardTitle>
          <CardDescription>Review organizational performance metrics</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays strategic reporting tools for NRWB management.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default StrategicReportsPage;
