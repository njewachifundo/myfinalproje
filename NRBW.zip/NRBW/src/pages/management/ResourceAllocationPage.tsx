
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const ResourceAllocationPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Resource Allocation</h1>
      <p className="text-nrwb-muted">Manage organizational resources</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Resource Management</CardTitle>
          <CardDescription>Allocate and track organizational resources</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays resource allocation tools for NRWB management.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default ResourceAllocationPage;
