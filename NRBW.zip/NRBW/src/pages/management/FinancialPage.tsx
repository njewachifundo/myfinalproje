
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const FinancialPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-nrwb-light">Financial Overview</h1>
      <p className="text-nrwb-muted">Access financial reports and insights</p>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>Financial Reports</CardTitle>
          <CardDescription>Review revenue, expenses, and financial forecasts</CardDescription>
        </CardHeader>
        <CardContent className="min-h-[400px] flex items-center justify-center">
          <p className="text-nrwb-muted">This page displays financial reporting tools for NRWB management.</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default FinancialPage;
