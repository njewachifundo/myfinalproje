
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  MessageSquare,
  FileText,
  AlertTriangle,
  Clock,
  CheckCircle,
  XCircle,
  ArrowRight,
  Calendar,
  PenTool,
} from 'lucide-react';

const StatusPage = () => {
  // Mock data for application status
  const application = {
    id: 'NRWB-2023-00457',
    status: 'Technical Review',
    progress: 60,
    submissionDate: '2023-04-20',
    lastUpdate: '2023-05-10',
    estimatedCompletion: '2023-07-15',
    stages: [
      {
        name: 'Submission',
        status: 'completed',
        date: '2023-04-20',
        description: 'Application submitted successfully.',
      },
      {
        name: 'Document Verification',
        status: 'completed',
        date: '2023-05-01',
        description: 'All submitted documents have been verified.',
      },
      {
        name: 'Technical Review',
        status: 'in-progress',
        date: '2023-05-10',
        description: 'Engineering team is evaluating technical feasibility.',
      },
      {
        name: 'Site Assessment',
        status: 'pending',
        description: 'Physical inspection of the connection site.',
      },
      {
        name: 'Quote Generation',
        status: 'pending',
        description: 'Cost estimate for the connection work.',
      },
      {
        name: 'Payment',
        status: 'pending',
        description: 'Payment processing for the connection fees.',
      },
      {
        name: 'Installation Planning',
        status: 'pending',
        description: 'Scheduling and resource allocation for the installation.',
      },
      {
        name: 'Connection Installation',
        status: 'pending',
        description: 'Physical installation of the water connection.',
      },
      {
        name: 'Final Inspection',
        status: 'pending',
        description: 'Quality check of the installed connection.',
      },
      {
        name: 'Completion',
        status: 'pending',
        description: 'Connection is active and operational.',
      },
    ],
    communications: [
      {
        id: 1,
        date: '2023-05-10',
        from: 'Technical Officer',
        message:
          'We have started the technical assessment of your application. You may be contacted for additional details if required.',
        read: true,
      },
      {
        id: 2,
        date: '2023-05-05',
        from: 'Document Verification Team',
        message:
          'All your submitted documents have been verified successfully. Your application has been forwarded to the technical team for review.',
        read: true,
      },
      {
        id: 3,
        date: '2023-04-20',
        from: 'System',
        message: 'Your application has been received. Application ID: NRWB-2023-00457',
        read: true,
      },
    ],
    pendingActions: [
      {
        id: 1,
        type: 'document',
        title: 'Land Title Verification',
        description:
          'Please provide additional proof of land ownership as the submitted document needs clarification.',
        dueDate: '2023-05-20',
      },
    ],
  };

  // Helper function to render status badge for each stage
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <Badge className="bg-green-600/20 text-green-400 hover:bg-green-600/30 flex items-center gap-1">
            <CheckCircle size={14} /> Completed
          </Badge>
        );
      case 'in-progress':
        return (
          <Badge className="bg-nrwb-accent/20 text-nrwb-accent hover:bg-nrwb-accent/30 flex items-center gap-1">
            <Clock size={14} /> In Progress
          </Badge>
        );
      case 'pending':
        return (
          <Badge className="bg-gray-600/20 text-gray-400 hover:bg-gray-600/30 flex items-center gap-1">
            <Clock size={14} /> Pending
          </Badge>
        );
      case 'rejected':
        return (
          <Badge className="bg-red-600/20 text-red-400 hover:bg-red-600/30 flex items-center gap-1">
            <XCircle size={14} /> Rejected
          </Badge>
        );
      default:
        return <Badge>{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2 text-nrwb-light">Application Status</h1>
        <p className="text-nrwb-muted">Track the progress of your water connection application</p>
      </div>

      <Card className="glass-dark">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Application #{application.id}</CardTitle>
            <p className="text-sm text-nrwb-muted mt-1">
              Submitted on {application.submissionDate}
            </p>
          </div>
          <Badge
            className="bg-nrwb-accent/20 text-nrwb-accent hover:bg-nrwb-accent/30 px-3 py-1.5"
            variant="outline"
          >
            {application.status}
          </Badge>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-nrwb-muted">Overall Progress</span>
              <span className="text-nrwb-accent">{application.progress}%</span>
            </div>
            {/* Fix: Remove indicatorClassName prop */}
            <Progress value={application.progress} className="h-2 bg-nrwb-dark" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-nrwb-dark/40 rounded-lg p-4 flex flex-col">
              <span className="text-nrwb-muted text-sm">Last Updated</span>
              <span className="text-lg font-medium mt-1">{application.lastUpdate}</span>
            </div>
            <div className="bg-nrwb-dark/40 rounded-lg p-4 flex flex-col">
              <span className="text-nrwb-muted text-sm">Current Stage</span>
              <span className="text-lg font-medium mt-1">{application.status}</span>
            </div>
            <div className="bg-nrwb-dark/40 rounded-lg p-4 flex flex-col">
              <span className="text-nrwb-muted text-sm">Estimated Completion</span>
              <span className="text-lg font-medium mt-1">{application.estimatedCompletion}</span>
            </div>
          </div>

          <Tabs defaultValue="timeline" className="w-full">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="timeline" className="data-[state=active]:bg-nrwb-accent/20">
                <Clock className="mr-2 h-4 w-4" /> Timeline
              </TabsTrigger>
              <TabsTrigger value="communications" className="data-[state=active]:bg-nrwb-accent/20">
                <MessageSquare className="mr-2 h-4 w-4" /> Communications
              </TabsTrigger>
              <TabsTrigger value="actions" className="data-[state=active]:bg-nrwb-accent/20">
                <AlertTriangle className="mr-2 h-4 w-4" /> Required Actions
              </TabsTrigger>
            </TabsList>

            <TabsContent value="timeline" className="border-none p-0 mt-4">
              <div className="space-y-4">
                {application.stages.map((stage, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg relative ${
                      stage.status === 'completed'
                        ? 'bg-green-900/20 border border-green-700/30'
                        : stage.status === 'in-progress'
                        ? 'bg-nrwb-accent/10 border border-nrwb-accent/30'
                        : 'bg-nrwb-dark/40'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-medium flex items-center">
                          {stage.status === 'completed' && (
                            <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
                          )}
                          {stage.status === 'in-progress' && (
                            <PenTool className="mr-2 h-4 w-4 text-nrwb-accent" />
                          )}
                          {stage.name}
                        </h3>
                        <p className="text-sm text-nrwb-muted mt-1">{stage.description}</p>
                      </div>
                      <div className="flex flex-col items-end">
                        {renderStatusBadge(stage.status)}
                        {stage.date && (
                          <span className="text-xs text-nrwb-muted mt-2 flex items-center">
                            <Calendar className="mr-1 h-3 w-3" /> {stage.date}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="communications" className="border-none p-0 mt-4">
              <div className="space-y-4">
                {application.communications.map((comm) => (
                  <div key={comm.id} className="bg-nrwb-dark/40 p-4 rounded-lg">
                    <div className="flex justify-between">
                      <span className="font-medium">{comm.from}</span>
                      <span className="text-xs text-nrwb-muted">{comm.date}</span>
                    </div>
                    <p className="text-sm text-nrwb-muted mt-2">{comm.message}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <Button className="w-full bg-nrwb-accent hover:bg-nrwb-accent/90">
                  Contact Support
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="actions" className="border-none p-0 mt-4">
              {application.pendingActions.length > 0 ? (
                <div className="space-y-4">
                  {application.pendingActions.map((action) => (
                    <div
                      key={action.id}
                      className="bg-amber-900/20 border border-amber-700/30 p-4 rounded-lg"
                    >
                      <div className="flex justify-between">
                        <span className="font-medium flex items-center">
                          <AlertTriangle className="mr-2 h-4 w-4 text-amber-400" />
                          {action.title}
                        </span>
                        <Badge variant="outline" className="bg-amber-900/30 text-amber-400">
                          Due: {action.dueDate}
                        </Badge>
                      </div>
                      <p className="text-sm text-nrwb-muted mt-2">{action.description}</p>
                      <Button className="mt-4 bg-nrwb-accent hover:bg-nrwb-accent/90">
                        Upload Document <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8">
                  <CheckCircle className="h-12 w-12 text-green-400 mb-4" />
                  <h3 className="text-xl font-medium">No Actions Required</h3>
                  <p className="text-nrwb-muted text-center mt-2">
                    There are currently no pending actions required from you.
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default StatusPage;
