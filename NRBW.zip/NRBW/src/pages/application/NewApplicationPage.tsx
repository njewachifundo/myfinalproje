import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CheckCircle, 
  Circle, 
  FileText, 
  Home, 
  MapPin, 
  Upload, 
  CheckCheck,
  Clock,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Progress } from '@/components/ui/progress';
import { Link, useNavigate } from 'react-router-dom';

// Define the steps in the application process
const steps = [
  { id: 'personal', label: 'Personal Details' },
  { id: 'property', label: 'Property Information' },
  { id: 'documents', label: 'Document Upload' },
  { id: 'location', label: 'Location' },
  { id: 'review', label: 'Review & Submit' }
];

const NewApplicationPage: React.FC = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState({
    // Personal Details
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    idType: '',
    idNumber: '',
    
    // Property Information
    propertyType: '',
    propertyUse: '',
    address: '',
    city: '',
    district: '',
    ownershipStatus: '',
    
    // Location
    latitude: '',
    longitude: '',
    
    // Documents
    idDocument: null as File | null,
    propertyDocument: null as File | null,
    otherDocument: null as File | null,
    
    // Additional Information
    additionalInfo: ''
  });
  
  // Calculate progress percentage
  const progress = ((currentStep + 1) / steps.length) * 100;
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fieldName: string) => {
    if (e.target.files && e.target.files[0]) {
      setFormData(prev => ({ ...prev, [fieldName]: e.target.files![0] }));
    }
  };
  
  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Application submitted successfully!');
    navigate('/application/status');
  };

  return (
    <div className="space-y-8 pb-10">
      <div>
        <h1 className="text-3xl font-bold text-nrwb-light">New Water Connection Application</h1>
        <p className="text-nrwb-muted mt-1">Fill out the form to apply for a new water connection</p>
      </div>
      
      <div className="relative">
        <Progress value={progress} className="h-2 w-full bg-nrwb-dark mb-6" />
        
        <div className="hidden md:flex justify-between mb-8">
          {steps.map((step, index) => (
            <div 
              key={step.id} 
              className={`flex flex-col items-center text-center w-1/5 relative ${
                index < currentStep ? 'text-nrwb-accent' : index === currentStep ? 'text-nrwb-light' : 'text-nrwb-muted/50'
              }`}
              style={{ cursor: 'default' }}
            >
              <div className={`
                w-10 h-10 rounded-full flex items-center justify-center mb-2
                ${index < currentStep 
                  ? 'bg-nrwb-accent text-nrwb-dark' 
                  : index === currentStep 
                    ? 'ring-2 ring-nrwb-accent bg-nrwb-dark/50' 
                    : 'bg-nrwb-dark/30'
                }
              `}>
                {index < currentStep ? (
                  <CheckCheck className="h-5 w-5" />
                ) : (
                  <span className="text-sm font-medium">{index + 1}</span>
                )}
              </div>
              <span className="text-sm mt-1">{step.label}</span>
            </div>
          ))}
        </div>
        
        <div className="md:hidden mb-6">
          <div className="flex items-center justify-between">
            <span className="text-nrwb-accent font-medium">Step {currentStep + 1} of {steps.length}</span>
            <span className="text-nrwb-muted">{steps[currentStep].label}</span>
          </div>
        </div>
      </div>
      
      <Card className="glass-dark">
        <CardHeader>
          <CardTitle>{steps[currentStep].label}</CardTitle>
          <CardDescription>
            {currentStep === 0 && "Provide your personal contact information"}
            {currentStep === 1 && "Tell us about your property"}
            {currentStep === 2 && "Upload required documentation"}
            {currentStep === 3 && "Mark your property location on the map"}
            {currentStep === 4 && "Review your application before submitting"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form id="application-form" onSubmit={handleSubmit}>
            {/* Step 1: Personal Details */}
            {currentStep === 0 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter your first name"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter your last name"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter your email address"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter your phone number"
                      required
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="idType">ID Type</Label>
                    <Select 
                      value={formData.idType} 
                      onValueChange={(value) => handleSelectChange('idType', value)}
                    >
                      <SelectTrigger className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent">
                        <SelectValue placeholder="Select ID Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="national_id">National ID</SelectItem>
                        <SelectItem value="passport">Passport</SelectItem>
                        <SelectItem value="drivers_license">Driver's License</SelectItem>
                        <SelectItem value="voters_id">Voter's ID</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="idNumber">ID Number</Label>
                    <Input
                      id="idNumber"
                      name="idNumber"
                      value={formData.idNumber}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter your ID number"
                    />
                  </div>
                </div>
              </div>
            )}
            
            {/* Step 2: Property Information */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="propertyType">Property Type</Label>
                    <Select 
                      value={formData.propertyType} 
                      onValueChange={(value) => handleSelectChange('propertyType', value)}
                    >
                      <SelectTrigger className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent">
                        <SelectValue placeholder="Select Property Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residential">Residential</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="industrial">Industrial</SelectItem>
                        <SelectItem value="institutional">Institutional</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="propertyUse">Property Use</Label>
                    <Select 
                      value={formData.propertyUse} 
                      onValueChange={(value) => handleSelectChange('propertyUse', value)}
                    >
                      <SelectTrigger className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent">
                        <SelectValue placeholder="Select Property Use" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="home">Home</SelectItem>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="office">Office</SelectItem>
                        <SelectItem value="shop">Shop</SelectItem>
                        <SelectItem value="factory">Factory</SelectItem>
                        <SelectItem value="school">School</SelectItem>
                        <SelectItem value="hospital">Hospital</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="address">Street Address</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                    placeholder="Enter the property address"
                    required
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="city">City/Town</Label>
                    <Input
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="Enter city or town"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="district">District</Label>
                    <Select 
                      value={formData.district} 
                      onValueChange={(value) => handleSelectChange('district', value)}
                    >
                      <SelectTrigger className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent">
                        <SelectValue placeholder="Select District" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mzuzu">Mzuzu</SelectItem>
                        <SelectItem value="nkhata_bay">Nkhata Bay</SelectItem>
                        <SelectItem value="karonga">Karonga</SelectItem>
                        <SelectItem value="rumphi">Rumphi</SelectItem>
                        <SelectItem value="chitipa">Chitipa</SelectItem>
                        <SelectItem value="likoma">Likoma</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Label>Ownership Status</Label>
                  <RadioGroup 
                    value={formData.ownershipStatus} 
                    onValueChange={(value) => handleSelectChange('ownershipStatus', value)}
                    className="grid grid-cols-1 md:grid-cols-2 gap-2"
                  >
                    <div className="flex items-center space-x-2 bg-nrwb-dark/30 p-3 rounded-lg hover:bg-nrwb-dark/40 transition-colors">
                      <RadioGroupItem value="owner" id="owner" />
                      <Label htmlFor="owner" className="cursor-pointer">Property Owner</Label>
                    </div>
                    <div className="flex items-center space-x-2 bg-nrwb-dark/30 p-3 rounded-lg hover:bg-nrwb-dark/40 transition-colors">
                      <RadioGroupItem value="tenant" id="tenant" />
                      <Label htmlFor="tenant" className="cursor-pointer">Tenant</Label>
                    </div>
                    <div className="flex items-center space-x-2 bg-nrwb-dark/30 p-3 rounded-lg hover:bg-nrwb-dark/40 transition-colors">
                      <RadioGroupItem value="agent" id="agent" />
                      <Label htmlFor="agent" className="cursor-pointer">Agent/Representative</Label>
                    </div>
                    <div className="flex items-center space-x-2 bg-nrwb-dark/30 p-3 rounded-lg hover:bg-nrwb-dark/40 transition-colors">
                      <RadioGroupItem value="other" id="other" />
                      <Label htmlFor="other" className="cursor-pointer">Other</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            )}
            
            {/* Step 3: Document Upload */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <div className="space-y-3">
                  <Label htmlFor="idDocument">ID Document (National ID, Passport, etc.)</Label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="border-2 border-dashed border-nrwb-muted/30 rounded-lg p-6 text-center">
                      <input
                        id="idDocument"
                        type="file"
                        className="hidden"
                        onChange={(e) => handleFileChange(e, 'idDocument')}
                        accept=".pdf,.jpg,.jpeg,.png"
                      />
                      <label 
                        htmlFor="idDocument" 
                        className="flex flex-col items-center cursor-pointer"
                      >
                        <Upload className="h-10 w-10 text-nrwb-muted mb-2" />
                        <span className="font-medium mb-1">Click to upload</span>
                        <span className="text-sm text-nrwb-muted">
                          {formData.idDocument ? formData.idDocument.name : 'PDF, JPG, JPEG or PNG (Max 5MB)'}
                        </span>
                      </label>
                    </div>
                    {formData.idDocument && (
                      <div className="bg-nrwb-accent/10 p-3 rounded-lg flex items-center gap-2">
                        <FileText className="h-5 w-5 text-nrwb-accent" />
                        <span className="truncate flex-1">{formData.idDocument.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-nrwb-muted hover:text-red-400"
                          onClick={() => setFormData(prev => ({ ...prev, idDocument: null }))}
                        >
                          Remove
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="propertyDocument">Property Ownership Document</Label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="border-2 border-dashed border-nrwb-muted/30 rounded-lg p-6 text-center">
                      <input
                        id="propertyDocument"
                        type="file"
                        className="hidden"
                        onChange={(e) => handleFileChange(e, 'propertyDocument')}
                        accept=".pdf,.jpg,.jpeg,.png"
                      />
                      <label 
                        htmlFor="propertyDocument" 
                        className="flex flex-col items-center cursor-pointer"
                      >
                        <Upload className="h-10 w-10 text-nrwb-muted mb-2" />
                        <span className="font-medium mb-1">Click to upload</span>
                        <span className="text-sm text-nrwb-muted">
                          {formData.propertyDocument 
                            ? formData.propertyDocument.name 
                            : 'Title deed, rental agreement, etc. (Max 5MB)'}
                        </span>
                      </label>
                    </div>
                    {formData.propertyDocument && (
                      <div className="bg-nrwb-accent/10 p-3 rounded-lg flex items-center gap-2">
                        <FileText className="h-5 w-5 text-nrwb-accent" />
                        <span className="truncate flex-1">{formData.propertyDocument.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-nrwb-muted hover:text-red-400"
                          onClick={() => setFormData(prev => ({ ...prev, propertyDocument: null }))}
                        >
                          Remove
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="otherDocument">Additional Documents (Optional)</Label>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="border-2 border-dashed border-nrwb-muted/30 rounded-lg p-6 text-center">
                      <input
                        id="otherDocument"
                        type="file"
                        className="hidden"
                        onChange={(e) => handleFileChange(e, 'otherDocument')}
                        accept=".pdf,.jpg,.jpeg,.png"
                      />
                      <label 
                        htmlFor="otherDocument" 
                        className="flex flex-col items-center cursor-pointer"
                      >
                        <Upload className="h-10 w-10 text-nrwb-muted mb-2" />
                        <span className="font-medium mb-1">Click to upload</span>
                        <span className="text-sm text-nrwb-muted">
                          {formData.otherDocument 
                            ? formData.otherDocument.name 
                            : 'Any other supporting documents (Max 5MB)'}
                        </span>
                      </label>
                    </div>
                    {formData.otherDocument && (
                      <div className="bg-nrwb-accent/10 p-3 rounded-lg flex items-center gap-2">
                        <FileText className="h-5 w-5 text-nrwb-accent" />
                        <span className="truncate flex-1">{formData.otherDocument.name}</span>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-nrwb-muted hover:text-red-400"
                          onClick={() => setFormData(prev => ({ ...prev, otherDocument: null }))}
                        >
                          Remove
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {/* Step 4: Location */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <div className="bg-nrwb-dark/30 p-4 rounded-lg mb-6">
                  <p className="text-nrwb-muted text-sm">
                    Please mark your property location on the map or enter the coordinates manually.
                    This will help our technical team locate your property for site assessment.
                  </p>
                </div>
                
                <div className="h-[300px] bg-nrwb-dark/50 rounded-lg flex items-center justify-center border border-nrwb-muted/20 mb-4">
                  <div className="text-center">
                    <MapPin className="h-10 w-10 text-nrwb-muted mb-2 mx-auto" />
                    <p className="text-nrwb-muted">Map integration will be available here</p>
                    <p className="text-nrwb-muted text-sm mt-1">
                      You can manually enter coordinates below
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="latitude">Latitude</Label>
                    <Input
                      id="latitude"
                      name="latitude"
                      value={formData.latitude}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="e.g., 11.4635"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="longitude">Longitude</Label>
                    <Input
                      id="longitude"
                      name="longitude"
                      value={formData.longitude}
                      onChange={handleInputChange}
                      className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent"
                      placeholder="e.g., 33.9895"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="additionalInfo">Additional Location Details (Optional)</Label>
                  <Textarea
                    id="additionalInfo"
                    name="additionalInfo"
                    value={formData.additionalInfo}
                    onChange={handleInputChange}
                    className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent min-h-[120px]"
                    placeholder="Provide any additional details that might help us locate your property (landmarks, directions, etc.)"
                  />
                </div>
              </div>
            )}
            
            {/* Step 5: Review & Submit */}
            {currentStep === 4 && (
              <div className="space-y-8">
                <div className="bg-nrwb-accent/10 p-4 rounded-lg text-center">
                  <h3 className="text-lg font-semibold mb-2">Application Review</h3>
                  <p className="text-nrwb-muted">
                    Please review all the information before submitting your application.
                  </p>
                </div>
                
                <div className="space-y-6">
                  <div className="neumorphic p-4 rounded-lg">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 text-nrwb-accent mr-2" />
                      Personal Details
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-nrwb-muted">Full Name:</p>
                        <p>{formData.firstName} {formData.lastName}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Contact:</p>
                        <p>{formData.email}</p>
                        <p>{formData.phone}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">ID Information:</p>
                        <p>{formData.idType === 'national_id' ? 'National ID' 
                           : formData.idType === 'passport' ? 'Passport'
                           : formData.idType === 'drivers_license' ? "Driver's License"
                           : formData.idType === 'voters_id' ? "Voter's ID" : "Not provided"}: {formData.idNumber || "Not provided"}</p>
                      </div>
                    </div>
                    <Button 
                      type="button" 
                      variant="link" 
                      className="text-nrwb-accent p-0 h-auto text-sm mt-2"
                      onClick={() => setCurrentStep(0)}
                    >
                      Edit Details
                    </Button>
                  </div>
                  
                  <div className="neumorphic p-4 rounded-lg">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 text-nrwb-accent mr-2" />
                      Property Information
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-nrwb-muted">Property Type:</p>
                        <p>{formData.propertyType === 'residential' ? 'Residential'
                           : formData.propertyType === 'commercial' ? 'Commercial'
                           : formData.propertyType === 'industrial' ? 'Industrial'
                           : formData.propertyType === 'institutional' ? 'Institutional'
                           : 'Not specified'}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Property Use:</p>
                        <p>{formData.propertyUse || 'Not specified'}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Address:</p>
                        <p>{formData.address}</p>
                        <p>{formData.city}, {formData.district}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Ownership Status:</p>
                        <p>{formData.ownershipStatus === 'owner' ? 'Property Owner'
                           : formData.ownershipStatus === 'tenant' ? 'Tenant'
                           : formData.ownershipStatus === 'agent' ? 'Agent/Representative'
                           : formData.ownershipStatus === 'other' ? 'Other'
                           : 'Not specified'}</p>
                      </div>
                    </div>
                    <Button 
                      type="button" 
                      variant="link" 
                      className="text-nrwb-accent p-0 h-auto text-sm mt-2"
                      onClick={() => setCurrentStep(1)}
                    >
                      Edit Details
                    </Button>
                  </div>
                  
                  <div className="neumorphic p-4 rounded-lg">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 text-nrwb-accent mr-2" />
                      Documents
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <p className="text-nrwb-muted">ID Document:</p>
                        <p>{formData.idDocument ? formData.idDocument.name : 'Not uploaded'}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Property Document:</p>
                        <p>{formData.propertyDocument ? formData.propertyDocument.name : 'Not uploaded'}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Additional Document:</p>
                        <p>{formData.otherDocument ? formData.otherDocument.name : 'Not uploaded'}</p>
                      </div>
                    </div>
                    <Button 
                      type="button" 
                      variant="link" 
                      className="text-nrwb-accent p-0 h-auto text-sm mt-2"
                      onClick={() => setCurrentStep(2)}
                    >
                      Edit Documents
                    </Button>
                  </div>
                  
                  <div className="neumorphic p-4 rounded-lg">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <CheckCircle className="h-5 w-5 text-nrwb-accent mr-2" />
                      Location
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-nrwb-muted">Coordinates:</p>
                        <p>Latitude: {formData.latitude || 'Not provided'}</p>
                        <p>Longitude: {formData.longitude || 'Not provided'}</p>
                      </div>
                      <div>
                        <p className="text-nrwb-muted">Additional Information:</p>
                        <p>{formData.additionalInfo || 'None provided'}</p>
                      </div>
                    </div>
                    <Button 
                      type="button" 
                      variant="link" 
                      className="text-nrwb-accent p-0 h-auto text-sm mt-2"
                      onClick={() => setCurrentStep(3)}
                    >
                      Edit Location
                    </Button>
                  </div>
                  
                  <div className="bg-nrwb-dark/30 p-4 rounded-lg">
                    <h4 className="font-semibold mb-2">Terms & Conditions</h4>
                    <div className="text-sm text-nrwb-muted">
                      <p>By submitting this application:</p>
                      <ul className="list-disc list-inside space-y-1 mt-2">
                        <li>You confirm that all information provided is accurate and complete.</li>
                        <li>You authorize NRWB to verify the information provided.</li>
                        <li>You agree to pay the applicable fees for the connection service.</li>
                        <li>You understand that submission of this application does not guarantee approval.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </form>
        </CardContent>
        <CardFooter className="flex justify-between border-t border-nrwb-dark/60 pt-4">
          <Button 
            type="button"
            variant="ghost" 
            onClick={prevStep}
            disabled={currentStep === 0}
            className="text-nrwb-muted hover:text-nrwb-light"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Previous
          </Button>
          
          {currentStep < steps.length - 1 ? (
            <Button 
              type="button"
              onClick={nextStep}
              className="bg-nrwb-accent hover:bg-nrwb-accent/90"
            >
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          ) : (
            <Button 
              type="submit"
              form="application-form"
              className="bg-nrwb-accent hover:bg-nrwb-accent/90"
            >
              Submit Application
              <CheckCheck className="ml-2 h-4 w-4" />
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default NewApplicationPage;
