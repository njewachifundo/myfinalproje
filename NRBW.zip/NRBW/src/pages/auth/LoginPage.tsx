
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, User, KeyRound } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";

const LoginPage: React.FC = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!username || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    
    setIsLoading(true);
    
    try {
      const success = await login(username, password);
      if (success) {
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('An error occurred during login');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-nrwb-darkest relative">
      <a 
        href="/" 
        className="absolute top-8 left-8 flex items-center text-nrwb-muted hover:text-nrwb-accent transition-colors"
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Home
      </a>
      
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(74,144,226,0.1)_0,rgba(74,144,226,0)_70%)] z-0"></div>
      
      <Card className="w-full max-w-md glass-dark z-10">
        <CardHeader className="space-y-1 text-center">
          <CardTitle className="text-2xl font-bold">Sign In</CardTitle>
          <CardDescription className="text-nrwb-muted">
            Enter your username and password to access your account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="relative">
                <User className="absolute left-3 top-2.5 h-4 w-4 text-nrwb-muted" />
                <Input
                  id="username"
                  placeholder="e.g. customer1, staff1, admin1, manager1"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link
                  to="/forgot-password"
                  className="text-sm text-nrwb-accent hover:text-nrwb-accent/80"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <KeyRound className="absolute left-3 top-2.5 h-4 w-4 text-nrwb-muted" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-nrwb-dark/50 border-nrwb-muted/30 focus:border-nrwb-accent pl-10"
                />
              </div>
            </div>
            <Alert variant="default" className="bg-nrwb-accent/10 border-nrwb-accent/20 text-nrwb-accent">
              <AlertTitle className="font-medium">Demo Login Credentials</AlertTitle>
              <AlertDescription>
                <p className="text-sm mt-1">Use any of the following accounts:</p>
                <ul className="text-xs mt-2 space-y-1">
                  <li><strong>Customer:</strong> customer1 / password1</li>
                  <li><strong>Staff:</strong> staff1 / password1</li>
                  <li><strong>Admin:</strong> admin1 / password1</li>
                  <li><strong>Manager:</strong> manager1 / password1</li>
                </ul>
              </AlertDescription>
            </Alert>
            <Button 
              type="submit" 
              className="w-full bg-nrwb-accent hover:bg-nrwb-accent/90"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing In
                </>
              ) : (
                'Sign In'
              )}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4 border-t border-nrwb-dark/60 pt-4">
          <div className="text-center text-sm text-nrwb-muted">
            Don't have an account?{' '}
            <Link
              to="/register"
              className="text-nrwb-accent hover:text-nrwb-accent/80 underline-offset-4 hover:underline"
            >
              Sign Up
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
};

export default LoginPage;
